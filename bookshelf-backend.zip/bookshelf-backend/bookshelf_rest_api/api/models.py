from django.db import models

# Create your models here.
class User(models.Model):
    # user_first_name = models.TextField(blank=True)
    # user_last_name = models.TextField(blank=True)
    # user_email = models.TextField(blank=True)
    # user_password = models.TextField(blank=True)
    user_first_name = 'John'
    user_last_name = 'Wick'
    user_email = 'email@ucdavis.edu'
    user_password = '1234'
    

class Book(models.Model):
    user_id = models.IntegerField()
    book_title = models.TextField(blank=True)
    book_author = models.TextField(blank=True)
    book_isbn = models.TextField(blank=True)