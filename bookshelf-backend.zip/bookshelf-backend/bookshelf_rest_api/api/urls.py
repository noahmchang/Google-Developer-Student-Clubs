from django.urls import path

from api import views

urlpatterns = [
    path("test/", views.TestView.as_view(), name="test"),
    path("signup/", views.SignUp.as_view(), name="signup"),
    path("signin/", views.SignIn.as_view(), name="signin"),
    path("books/", views.Books.as_view(), name="books"),
]