from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response

from .models import User, Book

# Create your views here.
class TestView(APIView):
    def get(self, request, format=None):
        return Response("This is a test")

class SignUp(APIView):
    def post(self, request, format=None):
        # user_first_name = request.POST.get('first_name')
        # user_last_name = request.POST.get('last_name')
        # user_email = request.POST.get('email')
        # user_password = request.POST.get('password')
        user_first_name = 'John'
        user_last_name = 'Wick'
        user_email = 'email@ucdavis.edu'
        user_password = '1234'
        user_obj = User(user_first_name=user_first_name, user_last_name=user_last_name,
            user_email=user_email, user_password=user_password)
        user_obj.save()
        return Response()

class SignIn(APIView):
    def post(self, request, format=None):
        # user_email = request.POST.get('email')
        # user_password = request.POST.get('password')
        user_email = 'email@ucdavis.edu'
        user_password = '1234'
        user_obj = User(user_first_name='John', user_last_name='Wick',
            user_email='email@ucdavis.edu', user_password='1234')
        user_obj.save()
        try:
            user_obj = User.objects.get(user_email=user_email, user_password=user_password)
        except User.DoesNotExist:
            return Response(status=412)
        else:
            return Response(status=200, data={"user_id": user_obj.id})

class Books(APIView):
    def get(self, request, format=None):
        user_id = int(request.GET.get("user_id"))
        q_books = Book.objects.all().filter(user_id=user_id)
        l_books = []
        for book_obj in q_books:
            d_book = {}
            d_book["title"] = book_obj.book_title
            d_book["author"] = book_obj.book_author
            d_book["isbn"] = book_obj.book_isbn
            l_books.append(d_book)
        return Response(status=200, data={"books": l_books})
    
    def post(self, request, format=None):
        user_id = int(request.POST.get("user_id"))
        book_title = request.POST.get("title")
        book_author = request.POST.get("author")
        book_isbn = request.POST.get("isbn")

        book_obj = Book(user_id=user_id, book_title=book_title, book_author=book_author,
            book_isbn=book_isbn)
        book_obj.save()
        d_book = {}
        d_book["title"] = book_obj.book_title
        d_book["author"] = book_obj.book_author
        d_book["isbn"] = book_obj.book_isbn
        return Response(status=200, data={"book": d_book})