import React from "react";

import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Form from 'react-bootstrap/Form';
import Table from "react-bootstrap/Table";

import axios from "axios";

interface TableData {
    title: string,
    author: string,
    isbn: string
}

function BookShelf() {
    const [isSignIn, setIsSignIn] = React.useState(false);
    const [isShowAddBookForm, setIsShowAddBookForm] = React.useState(false);
    const [tableData, setTableData] = React.useState<TableData[]>([]);

    //Form values
    const [title, setTitle] = React.useState("");
    const [author, setAuthor] = React.useState("");
    const [isbn, setIsbn] = React.useState("");

    React.useEffect(() => {
        if (localStorage.getItem("user_id") != null) {
            setIsSignIn(true);
            const requestResponse = axios.get("http://localhost:8000/api/books/", {
                params: {
                    user_id: localStorage.getItem("user_id")
                }
            })
            requestResponse.then((response) => {
                setTableData(response.data.books as TableData[]);
            })
        }
    }, [])

    const toggleAddBookForm = () => {
        setIsShowAddBookForm((prevValue) => {
            return !prevValue;
        })
    }

    const clearBookAddFormSubmit = () => {
        setTitle("");
        setAuthor("");
        setIsbn("");
    }

    const onBookAddFormSubmit = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        e.preventDefault();
        const formData = new FormData();
        let user_id = localStorage.getItem("user_id");
        if (user_id != null) {
            formData.append("user_id", user_id);
        }
        formData.append("title", title);
        formData.append("author", author);
        formData.append("isbn", isbn);

        const requestResponse = axios.post("http://localhost:8000/api/books/", formData);
        requestResponse.then((response) => {
            console.log(response);
            setTableData((prevTableData) => {
                return [...prevTableData, response.data.book as TableData];
            })
            clearBookAddFormSubmit();
            toggleAddBookForm(); //Form open, so it will close the form
        })
    }

    const getTable = () => {
        return (
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>ISBN</th>
                    </tr>
                </thead>
                <tbody>
                    {tableData.map((ele, index) => {
                        return (
                            <tr>
                                <td>{index + 1}</td>
                                <td>{ele.title}</td>
                                <td>{ele.author}</td>
                                <td>{ele.isbn}</td>
                            </tr>
                        )
                    })}
                </tbody>
            </Table>
        )
    }

    const getAddBookForm = () => {
        if (isShowAddBookForm) {
            return (
                <Form>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>Tile</Form.Label>
                        <Form.Control type="text" placeholder="Enter Title" value={title}
                            onChange={(e) => setTitle(e.target.value)} />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>Author</Form.Label>
                        <Form.Control type="text" placeholder="Enter Author" value={author}
                            onChange={(e) => setAuthor(e.target.value)} />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Label>ISBN</Form.Label>
                        <Form.Control type="text" placeholder="Enter ISBN" value={isbn}
                            onChange={(e) => setIsbn(e.target.value)} />
                    </Form.Group>
                    <Button variant="primary" type="submit" onClick={onBookAddFormSubmit}>
                        Add Book
                    </Button>
                </Form>
            )
        }
    }

    if (isSignIn) {
        return (
            <>
                <p>Books in Bookshelf</p>
                <Button variant="primary" onClick={() => toggleAddBookForm()}>Add Book</Button>
                {getTable()}
                {getAddBookForm()}
            </>
        )
    } else {
        return <p>Please sign in before assessing bookshelf</p>
    }
}

export default BookShelf;