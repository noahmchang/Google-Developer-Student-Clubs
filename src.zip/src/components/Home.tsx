import Image from 'react-bootstrap/Image';

function Home() {
    return (
        <div>
            <h4 className="align-text-center">Welcome to your own personal Bookshelf. Review and Upload your favourite books! </h4>
            <Image src="bookshelfhome.PNG" />
        </div>
    )
}

export default Home;