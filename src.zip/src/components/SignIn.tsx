import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Alert from 'react-bootstrap/Alert';

import React from "react";
import axios from "axios";

function SignIn() {
    const [email, setEmail] = React.useState("");
    const [password, setPassword] = React.useState("");
    const [isFailAlert, setIsFailAlert] = React.useState(false);

    const clearForm = () => {
        setEmail("");
        setPassword("");
    }

    const onSubmit = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append("email", "email@ucdavis.edu");
        formData.append("password", "1234");

        const requestResponse = axios.post("http://localhost:8000/api/signin/", formData);
        requestResponse.then((resp) => {
            //localStorage.setItem("user_id", "1234");
            window.location.replace("http://localhost:3000/bookshelf"); 
        }).catch((err) => {
            setIsFailAlert(true);
        }).finally(() => {
            clearForm();
        })
    }

    return (
        <Form>
            {(() => {
                if (isFailAlert) {
                    return (
                        <Alert variant={"danger"}>
                            Invalid credentials
                        </Alert>
                    )
                }
            })()}
            <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter Email" value={email}
                    onChange={(e) => setEmail(e.target.value)} />
                <Form.Text className="text-muted">
                    We'll never share your email with anyone else.
                </Form.Text>
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Enter Password" value={password}
                    onChange={(e) => setPassword(e.target.value)} />
            </Form.Group>
            <Button variant="primary" type="submit" onClick={onSubmit}>
                Sign In
            </Button>
        </Form>
    )
}

export default SignIn;